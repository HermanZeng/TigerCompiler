#ifndef SEMANT_H
#define SEMANT_H


F_fragList SEM_transProg(A_exp exp);

#endif