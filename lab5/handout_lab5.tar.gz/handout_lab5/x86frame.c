#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "util.h"
#include "symbol.h"
#include "temp.h"
#include "table.h"
#include "tree.h"
#include "frame.h"

/*Lab5: Your implementation here.*/

struct F_frame_ {

};


F_frag F_StringFrag(Temp_label label, string str) {
	return NULL;
}

F_frag F_ProcFrag(T_stm body, F_frame frame) {
	return NULL;
}

F_fragList F_FragList(F_frag head, F_fragList tail) {
	return NULL;
}


